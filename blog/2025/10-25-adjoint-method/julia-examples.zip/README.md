# Backpropagation is the Adjoint Method

- `linear_adjoint.jl`: the adjoint method for a linear constraint, checked against ForwardDiff.
- `neural_network_adjoint.jl`: the adjoint method for a small network, checked against finite differences.

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. linear_adjoint.jl
julia --project=. neural_network_adjoint.jl
```
