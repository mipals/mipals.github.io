# Structured Masked Attention (SMA)

- `low_rank_mask.jl`: masked attention with a low-rank mask.
- `scalar_state_space.jl`: a state-space model with scalar states as masked attention.
- `state_space_semiseparable.jl`: the state-space model as a semiseparable matrix.

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. low_rank_mask.jl
julia --project=. scalar_state_space.jl
julia --project=. state_space_semiseparable.jl
```
