# The Boundary Element Method

- `pulsating_sphere.jl`: the pulsating sphere, computed with the BEM using [BoundaryIntegralEquations.jl](https://github.com/mipals/BoundaryIntegralEquations.jl) and analytically.
- `figures.jl`: the result figure of the post, `pulsating_sphere_results.pdf` in `../figures`, with a `_dark` version for the dark page.
- `../figures/sparsity_pattern.tex`: the figure of the near-field sparsity patterns. Compile it in `../figures`, once as is and once for the dark page:

  ```sh
  pdflatex sparsity_pattern.tex
  pdflatex -jobname=sparsity_pattern_dark '\def\darkmode{1}\input{sparsity_pattern.tex}'
  ```

BoundaryIntegralEquations.jl is not registered; `Project.toml` points Pkg to its repository (this requires Julia 1.11 or newer).

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. pulsating_sphere.jl
julia --project=. figures.jl
```
