# Which Way Is Down? First-Order Optimizers as a Choice of Norm

- `sharp.jl`: the sharp of a derivative for several norms, from its definition and in closed form.

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. sharp.jl
```
