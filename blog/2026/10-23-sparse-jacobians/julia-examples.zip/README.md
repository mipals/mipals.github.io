# When the Jacobian Is Dense but the Program Is Not

- `tape.jl`: a scalar tape that records the sparse matrices L, Mᵀ and P of a function.
- `sparse_solve.jl`: the Jacobian as `P * (L \ Mt)` with SparseSparse.jl, sparse for the Bratu residual and dense for the heating residual.
- `augmented_solve.jl`: the Newton step as a solve with the sparse augmented matrix A = [L -Mᵀ; P 0] instead of J.
- `problems.jl`: the Bratu and heating residuals, and the lifted heating residual.
- `heating.jl`: Newton's method for a nonlocal heating problem, whose Jacobian is dense, with the augmented system.
- `heating_lifting.jl`: Newton steps for the heating problem with DifferentiationInterface.jl on the residual lifted with every partial sum of the integral.
- `heating_lifting_jax.py`: the same lifted residual in JAX, with the sparse Jacobian from asdex and the solve from SciPy.
- `heating_jax.py`: Newton steps for the heating problem in JAX, which forms the dense Jacobian with `jax.jacfwd` or `jax.jacrev` and solves densely.
- `figures.jl`: the figure of the estimation for a small problem, for the light and the dark page.
- `heating_lifted.jl`: estimating the parameter of the heating problem with Uno through JuMP, with the integral inside every equation and lifted.

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. sparse_solve.jl
julia --project=. heating.jl
julia --project=. heating_lifting.jl
julia --project=. heating_lifted.jl
julia --project=. figures.jl
```

The Python scripts need JAX, asdex and SciPy, pinned in `requirements.txt` (asdex does not yet support JAX 0.12), for example in a virtual environment:

```sh
uv venv --python 3.13 .venv
uv pip install --python .venv/bin/python -r requirements.txt
.venv/bin/python heating_jax.py
.venv/bin/python heating_lifting_jax.py
```
