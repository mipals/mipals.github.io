# The Finite Element Method

- `assembly_1d.jl`: assembly of the one-dimensional system.
- `impedance_tube.jl`: the impedance tube; includes `assembly_1d.jl`.
- `modes_geometry.jl`: the two-dimensional geometry, included by the mode scripts.
- `modes_fem.jl`: the modes computed with finite elements, compared with the analytical ones.
- `figures.jl`: the result figures of the post, `impedance_results.pdf` and `modes_results.pdf` in `../figures`, each with a `_dark` version for the dark page.
- `../figures/impedance_tube.tex`: the impedance tube figure. Compile it in `../figures`, once as is and once for the dark page:

  ```sh
  pdflatex impedance_tube.tex
  pdflatex -jobname=impedance_tube_dark '\def\darkmode{1}\input{impedance_tube.tex}'
  ```

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. assembly_1d.jl
julia --project=. impedance_tube.jl
julia --project=. modes_fem.jl
julia --project=. figures.jl
```
