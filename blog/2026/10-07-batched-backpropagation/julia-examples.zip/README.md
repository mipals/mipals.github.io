# Batched Backpropagation as a Linear Solve

- `backbackback.jl`: the batch gradient of a network with skip connections and a shared weight block, with sparse operator matrices and a sparse adjoint solve.

```sh
julia backbackback.jl
```
