# Dual Numbers for Automatic Differentiation

- `dual_numbers.jl`: dual numbers and the scalar derivative.
- `jvp.jl`: Jacobian-vector products.
- `main.jl`: runs both.

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. main.jl
```
